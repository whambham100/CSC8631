filtered_enrolments = select(combined_enrolments, learner_id, rep, gender, age_range, highest_education_level, employment_status, employment_area, detected_country,)
