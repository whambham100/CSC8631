ggplot(combined_enrolments, aes(x=gender))+
  geom_bar(stat = "count")
