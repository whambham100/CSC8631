ggplot(videostats_yr1, aes(x = , y = video_duration)) +
  geom_boxplot()
