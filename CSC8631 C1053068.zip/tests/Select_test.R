select(combined_enrolments, learner_id, gender, detected_country, age_range,)
